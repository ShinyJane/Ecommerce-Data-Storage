import csv
import database as db

PW = "admin@123" # IMPORTANT! Put your MySQL Terminal password here.
ROOT = "root"
DB = "ecommerce_record" # This is the name of the database we will create in the next step - call it whatever you like.
LOCALHOST = "localhost"
connection = db.create_server_connection(LOCALHOST, ROOT, PW)

# creating the schema in the DB 
db.create_switch_database(connection, DB, DB)


RELATIVE_CONFIG_PATH = '../config/'

USER = 'users'
ITEM = 'items'
ORDER = 'orders'

# Create the tables through python code here
# if you have created the table in UI, then no need to define the table structure
# If you are using python to create the tables, call the relevant query to complete the creation

#Creating users table
create_users_table = """
     CREATE TABLE users(
          user_id varchar(10) PRIMARY KEY,
          user_email varchar(45) NOT NULL,
          user_name varchar(45) NOT NULL,
          user_password varchar(45) NOT NULL,
          user_address varchar(45) NULL,
          is_vendor tinyint(1) DEFAULT 0
          )
"""

print("Intializing creation of users table: ")
db.create_insert_query(connection, create_users_table)
print("Users table is created.")

#Creating orders table
create_orders_table = """
      CREATE TABLE orders(
            order_id int NOT NULL PRIMARY KEY,
            total_value float(45) NOT NULL,
            customer_id varchar(10) NOT NULL,
            vendor_id varchar(10) NOT NULL,
            order_quantity int NOT NULL,
            is_vendor tinyint(1) DEFAULT 0
            )
"""

with open(RELATIVE_CONFIG_PATH+USER+'.csv', 'r') as f:
    val = []
    data = csv.reader(f)
    for row in data:
        val.append(tuple(row))
    val.pop(0)
    sql = '''
            INSERT INTO USERS (user_id, user_name, user_email, user_password)
            VALUES (%s, %s, %s, %s)
          '''
    db.insert_many_data(connection,sql,val)
    print("Data insertion in users table is completed.")

    """
    Here we have accessed the file data and saved into the val data struture, which list of tuples. 
    Now you should call appropriate method to perform the insert operation in the database. 
    """

print("Data insertion in items table is intiated")
with open(RELATIVE_CONFIG_PATH+ITEM+'.csv', 'r') as f:
    val = []
    data = csv.reader(f)
    for row in data:
        val.append(tuple(row))
    val.pop(0)
    """
    Here we have accessed the file data and saved into the val data struture, which list of tuples. 
    Now you should call appropriate method to perform the insert operation in the database. 
    """


with open(RELATIVE_CONFIG_PATH+ORDER+'.csv', 'r') as f:
    val = []
    data = csv.reader(f)
    for row in data:
        val.append(tuple(row))

    val.pop(0)
    """
    Here we have accessed the file data and saved into the val data struture, which list of tuples. 
    Now you should call appropriate method to perform the insert operation in the database. 
    """