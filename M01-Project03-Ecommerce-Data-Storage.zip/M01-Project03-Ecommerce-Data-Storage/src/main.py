import database as db

# Driver code
if __name__ == "__main__":

    """
    Please enter the necessary information related to the DB at this place. 
    Please change PW and ROOT based on the configuration of your own system. 
    """
    PW = "admin@123" # IMPORTANT! Put your MySQL Terminal password here.
    ROOT = "root"
    DB = "ecommerece_record" # This is the name of the database we will create in the next step - call it whatever you like.
    LOCALHOST = "localhost"
    connection = db.create_server_connection(LOCALHOST, ROOT, PW)

    # creating the schema in the DB 
    db.create_switch_database(connection, DB, DB)

    # Start implementing your task as mentioned in the problem statement 
    # Implement all the test cases and test them by running this file
    print("Inserting the additional data points in the orders table: ")
    insert_into_orders = """
    INSERT INTO orders VALUES
    (101, 23532, '5', '2', 2, 400),
    (102, 53975, '11', '5', 4, 100),
    (103, 46894, '13', '1', 5, 300),
    (104, 87694, '14', '4', 6, 200),
    (105, 25467, '6', '3', 1, 130);
    """
    db.create_insert_query(connection, insert_into_orders)

    print("The details of all the orders inserted in the table: ")
    select_orders = """select * from orders """
    results = db.select_query(connection, select_orders)
    for result in results:
        print(result)

    print("The order with minimum value is: ")
    select_min_orders = """Select * from orders where total_value in (select min (total_value) from orders)"""
    results = db.select_query(connection, select_min_orders)
    for result in results:
        print(result)

    print ("The order with maximum value is: ")
    select_max_orders = """ Select * from orders where total_value in (select max (total_value) from orders"""
    results = db.select_query(connection, select_max_orders)
    for result in results:
        print(result)

    print("All the order details with value greater than the average order value: ")
    select_order_details = """select * from orders where
    total_value > (select avg(total_value) from orders)"""
    results = db.select_query(connection, select_order_details)
    for result in results:
        print(result)

    #Creating customer leaderboard table
    print("Creation of customer leaderboard table.")
    create_customer_leaderboard = """
           CREATE TABLE customer_leaderboard(
                customer_id varchar(10) NOT NULL PRIMARY KEY,
                total_value float (45) NOT NULL,
                customer_name varchar (50) NOT NULL,
                customer_email varchar (50) NOT NULL,
                FOREIGN KEY (customer_id) REFERENCES users(user_id)
                )
            """
    db.create_insert_query(connection, create_customer_leaderboard)
    print("Customer leaderboard table is created.")

    print("Initiating data insertion in customer leadership table: ")

    insert_leader_table = """insert into customer_leaderboard (select customer_id, max(total_value), user_name,
            user_email from orders, users where users.user_id = orders.customer_id group by customer_id);"""
    db.create_insert_query(connection, insert_leader_table)
    print("Data is inserted into the table.")

    select_customer_leader = """select * from customer_leaderboard"""
    results = db.select_query(connection, select_customer_leader)
    for result in results:
                print(result)